var screenNum;
var gameNum;
var playButton;
var gameButton1;
var gameButton2;
var gameButton3;
var tryAgainButton;
var homeButton;

//first screen
function drawHome() {
  //boxes and text
  background('#FFE2F8');
  fill('#A8DDFC');
  rect(26, 25, 245, 85, 20);
  textSize(36);
  fill(50);
  text('Welcome!', 83, 70);
  textSize(16);
  fill(50);
  text('Let\'s get started!', 100, 95);
  
  //play button
  playButton = createButton('Play');
  playButton.position(26,200);
  playButton.style('background-color','#A8FCD7');
  playButton.style('font-size', '60px');
  playButton.style('color', '50');
  playButton.size(245,200);
  playButton.mousePressed(drawPickGame);
  
  //hides the other buttons
  tryAgainButton.hide();
  homeButton.hide();
}

function drawPickGame(){
  // pick a game box
  screenNum = 2;
  playButton.hide();
  background('#FFE2F8');
  fill('#A8DDFC');
  rect(10, 20, 280, 65, 10)
  
  // pick a game text
  textSize(32);
  fill(50);
  text("Pick a Game!", 75, 65);
  
  // trace the line box
  fill('#FEFFE1');
  rect(10, 100, 280, 105, 0, 0, 10, 10);
  textSize(16);
  fill(0);
  text("Follow the maze", 103, 178);
  textSize(16);
  fill(0);
  text("as quickly as possible.", 83, 198);
  
  // Trace the shape box
  fill('#DDFFD4');
  rect(10, 230, 280, 105, 0, 0, 10, 10);
  textSize(16);
  fill(0);
  text("Keep your cursor on the box", 65, 308);
  textSize(16);
  fill(0);
  text("as much as you can.", 90, 328);

  //resize and move the shape box
  fill('#FFE4E4');
  rect(10, 360, 280, 105, 0, 0, 10, 10);
  textSize(16);
  fill(0);
  text("Match the circle with its counterpart ", 38, 438);
  text("as quickly as possible.", 85, 458);
  
  //creates button for the first game
  gameButton1 = createButton('Follow the Maze');
  gameButton1.position(10,100);
  gameButton1.mousePressed(drawGame1);
  gameButton1.style('background-color','#FAFF69');
  gameButton1.style('font-size', '25px');
  gameButton1.style('color', '50');
  gameButton1.size(280,60);
  
  //creates button for the second game
  gameButton2 = createButton('Stay on the Box');
  gameButton2.position(10,230);
  gameButton2.mousePressed(drawGame2);
  gameButton2.style('background-color','#A5FF8E');
  gameButton2.style('font-size', '25px');
  gameButton2.style('color', '50');
  gameButton2.size(280,60);
  
  //creates button for the third game
  gameButton3 = createButton('Match the Circles');
  gameButton3.position(10,360);
  gameButton3.mousePressed(drawGame3);
  gameButton3.style('background-color','#FF6666');
  gameButton3.style('font-size', '25px');
  gameButton3.style('color', '50');
  gameButton3.size(280,60);
  
  //hides the other buttons
  tryAgainButton.hide();
  homeButton.hide();

}

function randomVar(){
  variant = round(random(1,5));
}
function timers(){
  if (timer > 0){
    timer = 0;
  }
}

