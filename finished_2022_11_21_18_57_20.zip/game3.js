let ring;
let pointer;
let x;
let y;
let score = 0;

function game3() {
  if (frameCount % 60 == 0 && timer < 100){
      timer ++;
      timeB = timer;
  }
  strokeWeight(3);
  stroke('black');
  point_circle= circle(x, y, 130);
  strokeWeight(0);
     // control circle 
  fill(255, 400, 0);
  circle(mouseX, mouseY, 129);
  noFill();
  
  // Point Circle do not move
  if ((mouseX == x) && (mouseY == y)) {
    if(ring.isPlaying() == false){
      ring.play() 
    }
    score++;
    drawResultScreen();
  }
}

function randomXY(){
  x = round(random(75,230));
  y = round(random(175,425));
}