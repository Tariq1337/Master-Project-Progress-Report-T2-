new p5;
var timer = 0;
var timer2 = 10;
var variant = 0;
var timeA = 0;
var timeB = 0;
var timeC = 0;
var scoreA = 0;
var game1Result;
var fonts;

function preload() {
  ring = loadSound("ring1.wav");
  ping = loadSound("ping.wav");
  lose = loadSound("lose.mp3");
  fonts = loadFont("Antonio-Regular.ttf");
}

function setup() {
  createCanvas(300, 500);
  textFont(fonts);
  //button to try again on result screen
  tryAgainButton = createButton('Try Again?');
  tryAgainButton.position(73,290);
  tryAgainButton.style('background-color','#A8FCD7');
  tryAgainButton.style('font-size', '25px');
  tryAgainButton.style('color', '50');
  tryAgainButton.size(150,65);
  
  //button to go home on result screen
  homeButton = createButton('Home');
  homeButton.position(73,380);
  homeButton.mousePressed(drawHome);
  homeButton.style('background-color','#A8FCFC');
  homeButton.style('font-size', '25px');
  homeButton.style('color', '50');
  homeButton.size(150,65);
  
  screenNum = 1;
  
  randomXY();
  randomStart();
  
  noLoop();
}

function draw(){
  if (screenNum == 1){
    noLoop();
    drawHome();
  } else if (screenNum == 2){
    noLoop();
    drawPickGame();
  } else if (screenNum == 3){
    background(220);
    drawGame1();
  } else if (screenNum == 4){
    drawGame2();
  } else if (screenNum == 5){
    drawGame3();
  } else {
    drawResultScreen();
  }
}

//draws the first game (when we finish it)
function drawGame1(){
  //tracks that it is the first game and hides other buttons, creates shapes and text
  screenNum = 3;
  gameNum = 1;
  tryAgainButton.hide();
  homeButton.hide();
  gameButton1.hide();
  gameButton2.hide();
  gameButton3.hide();
  stroke(0);
  strokeWeight(0);
  fill('#A8DDFC');
  rect(0, 0, 300, 110);
  textSize(30)
  fill(50);
  text('Follow The Maze!', 60, 40);
  textSize(50);
  text(timer + 's', 130, 95);
  drawLine(variant);
  mouseDraw();
  loop();
}

//draws the second game (when we finish it)
function drawGame2(){
  //tracks that it is the second game and hides other buttons, creates shapes and text
  gameNum = 2;
  screenNum = 4;
  gameButton1.hide();
  gameButton2.hide();
  gameButton3.hide();
  background(220);
  fill('#A8DDFC');
  rect(0, 0, 1200, 110);
  textSize(30)
  fill(50);
  text('Stay on the Box!', 65, 45);
  textSize(50);
  text(score2 + "%", 170, 95);
  textSize(50);
  text(timer2 + "s", 45, 95);
  game2();
  loop();
  
  //hides the other buttons and shows the temp one
  tryAgainButton.hide();
  homeButton.hide();
}

function drawGame3(){
  //tracks that it is the third game and hides other buttons, creates shapes and text
  gameNum = 3;
  screenNum = 5;
  gameButton1.hide();
  gameButton2.hide();
  gameButton3.hide();
  background(220);
  fill('#A8DDFC');
  rect(0, 0, 1200, 110);
  textSize(30)
  fill(50);
  text('Match the Circles!', 51, 45);
  textSize(30);
  text('Score: ' + score, 160, 90);
  textSize(30);
  text(timer + 's', 50, 90);
  game3();
  loop();
  
  //hides the other buttons and shows the temp one
  tryAgainButton.hide();
  homeButton.hide();
}
//draws the result screen
function drawResultScreen(){
  //hides the temp button and shows the others, draws shapes and text
  noLoop();
  tryAgainButton.show();
  homeButton.show();
  screenNum = 6;
  strokeWeight(0);
  background('#FFE2F8');
  fill('#FFFFE0');
  rect(10, 20, 280, 75, 10);
  fill('#A8DDFC');
  rect(10,110, 280, 150, 10);
  
  textSize(50);
  fill(50);
  text('Results', 85, 80);
  
//checks what game the user came from and sends them back to it when they press the try again button
  if (gameNum == 1){
    textSize(30);
    text('Time (seconds): ' + timeA, 25, 220);
    textSize(50);
    text(game1Result, 25, 180);
    randomVar();
    tryAgainButton.mousePressed(drawGame1);
    timers();
  } else if (gameNum == 2){
    timer2 = 10;
    score2 = 100;
    textSize(40);
    text('Accuracy: ' + scoreA + '%', 25, 200);
    randomStart();
    randomSpeed();
    tryAgainButton.mousePressed(drawGame2);
  } else if (gameNum == 3){
    randomXY();
    timers();
    textSize(30);
    text('Time (seconds): ' + timeB, 25, 220);
    textSize(50);
    text('Score: ' + score, 25, 180);
    tryAgainButton.mousePressed(drawGame3);
  }
}
function randomVar(){
  variant = round(random(1,5));
}
function timers(){
  if (timer >= 0){
    timer = 0;
  }
}
