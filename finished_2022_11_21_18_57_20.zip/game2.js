var x1 = 0;
var y1 = 0;
var dx = 2.1;
var dy = 1.5;
var score2 = 100;
var ping;

function game2(){
  if (frameCount % 60 == 0 && timer2 > 0){
      timer2 --;
  }
  
  x1 += dx;
  y1 += dy;
  
  if (x1 < 0 || x1 > width-50){
    dx = -dx;
  }
  if (y1 < 110 || y1 > height-50){
    dy = -dy;
  }
  
  square(x1,y1,50);
  
  if (((mouseX > x1 && mouseX < x1+50)) && ((mouseY > y1 && mouseY < y1+50))){
    if(ping.isPlaying() == false){
      ping.play() 
    }
  } else if (frameCount % 6 == 0 && score2 > 0){
      score2--;
      scoreA = score2;
    }
  if (timer2 == 0){
    drawResultScreen();
  }
}

function randomStart(){
  x1 = random(50,225);
  y1 = random(120, 400);
}

function randomSpeed(){
  dx = random(1, 3);
  dy = random(1, 3);
}

