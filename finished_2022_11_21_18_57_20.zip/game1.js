var lose;
function drawLine(variant){
  stroke(0);
  strokeWeight(2);
  if (variant == 1){
    fill('green');
    rect(0, 150, 25, 50);
    fill ('black');
    square(275, 400, 25);
    fill ('white');
    square(275, 375, 25);
    line(0, 150,100, 150);
    line(100, 150, 100, 250);
    line(100, 250, 200, 250);
    line(200, 250, 200 ,375);
    line(200, 375, 300, 375);
    line(0, 200, 50, 200);
    line(50, 200, 50, 300);
    line(50, 300, 150, 300);
    line(150, 300, 150, 425);
    line(150, 425, 300, 425);
  } else if (variant == 2){
    fill('green');
    rect(0, 400, 25, 50);
    fill ('black');
    square(225, 475, 25);
    fill ('white');
    square(250, 475, 25);
    line(0, 400, 50, 400);
    line(50, 400, 50, 150);
    line(50, 150, 275, 150);
    line(275, 150, 275, 500);
    line(0, 450, 100, 450);
    line(100, 450, 100, 200);
    line(100, 200, 225, 200);
    line(225, 200, 225, 500);
  } else if (variant == 3){
    fill('green');
    rect(25, 475, 50, 25);
    fill ('black');
    square(275, 150, 25);
    fill ('white');
    square(275, 175, 25);
    line(25, 500, 25, 150);
    line(75, 500, 75, 200);
    line(25, 150, 125, 150);
    line(75, 200, 125, 200);
    line(125, 150, 175, 150);
    line(125, 200, 125, 450);
    line(175, 150, 175, 400);
    line(175, 400, 200, 400);
    line(200, 400, 200, 150);
    line(200, 150, 300, 150);
    line(125, 450, 250, 450);
    line(250, 450, 250, 200);
    line(250, 200, 300, 200);
  } else {
    fill('green');
    rect(100, 475, 50, 25);
    fill ('black');
    square(275, 150, 25);
    fill ('white');
    square(275, 175, 25);
    line(300, 150, 50, 150);
    line(50, 150, 50, 300);
    line(50, 300, 100, 300);
    line(100, 300, 100, 500);
    line(300, 200, 100, 200);
    line(100, 200, 100, 250);
    line(100, 250, 150, 250);
    line(150, 250, 150, 500);
  }
}

function mouseDraw(){
  strokeWeight(10);
  if (mouseIsPressed === true) {
    if (frameCount % 60 == 0 && timer < 100){
      timer ++;
      timeA = timer;
    }
      changeBack();
      line(mouseX, mouseY, pmouseX, pmouseY);
    }
}
function changeBack(){
  if (variant == 1){
    if((((mouseY < 200) && (mouseY > 150)) && (mouseX < 100)) || (((mouseY > 150) && (mouseY < 300)) && ((mouseX > 50) && (mouseX < 100))) || (((mouseY > 250) && (mouseY < 300)) && ((mouseX > 50) && (mouseX < 200))) || (((mouseY > 250) && (mouseY < 425)) && ((mouseX > 150) && (mouseX < 200))) || (((mouseY > 375) && (mouseY < 425)) && ((mouseX > 150) && (mouseX < 300)))){
      stroke('#00FF00');
      if (((mouseX > 275) && (mouseY < 425) && (mouseY > 375)) && timer >= 2){
        if(ring.isPlaying() == false){
          ring.play() 
        }
        game1Result = "You Won!"
        drawResultScreen();
      }
    } else if (timer > 0) {
      game1Result = "You Lost!"
      if(lose.isPlaying() == false){
          lose.play() 
      }
      drawResultScreen();
    }
  } else if (variant == 2){
    if((((mouseY < 450) && (mouseY > 400)) && (mouseX < 100)) || (((mouseY < 450) && (mouseY > 150)) && ((mouseX > 50) && (mouseX < 100))) || ((mouseY > 150) && (mouseY < 200) && (mouseX < 275) && (mouseX > 50)) || ((mouseY > 150) && (mouseX > 225) && (mouseX < 275))){
      stroke('#00FF00');
      if (((mouseX > 225) && (mouseX < 275) && (mouseY > 475)) && timer >= 2){
        if(ring.isPlaying() == false){
          ring.play() 
        }
        game1Result = "You Won!"
        drawResultScreen();
      }
    } else if (timer > 0) {
      game1Result = "You Lost!"
      if(lose.isPlaying() == false){
          lose.play() 
      }
      drawResultScreen();
    }
  } else if (variant == 3){
    if(((mouseY > 150) && (mouseX > 25) && (mouseX < 75)) || ((mouseY > 150) && (mouseY < 200) && (mouseX < 175) && (mouseX > 75)) || ((mouseY > 150) && (mouseY < 450) && (mouseX > 125) && (mouseX < 175)) || ((mouseY > 400) && (mouseY < 450) && (mouseX > 125) && (mouseX < 250)) || ((mouseY < 450) && (mouseY > 150) && (mouseX > 200) && (mouseX < 250)) || ((mouseY > 150) && (mouseY < 200) && (mouseX > 200))){
      stroke('#00FF00');
      if (((mouseX > 275) && (mouseY < 200) && (mouseY > 150)) && timer >= 2){
        if(ring.isPlaying() == false){
          ring.play() 
        }
        game1Result = "You Won!"
        drawResultScreen();
      }
    } else if (timer > 0) {
      game1Result = "You Lost!"
      if(lose.isPlaying() == false){
          lose.play() 
      }
      drawResultScreen();
    }
  } else {
    if(((mouseY > 150) && (mouseY < 200) && (mouseX > 50) || ((mouseY > 150) && (mouseY < 300) && (mouseX > 50) && (mouseX < 100)) || ((mouseY > 250) && (mouseX > 99) && (mouseX < 150)))){
      stroke('#00FF00');
      if (((mouseX > 275) && (mouseY < 200) && (mouseY > 150)) && timer >= 1){
        if(ring.isPlaying() == false){
          ring.play() 
        }
        game1Result = "You Won!"
        drawResultScreen();
      }
    } else if (timer > 0) {
      game1Result = "You Lost!"
      if(lose.isPlaying() == false){
          lose.play() 
      }
      drawResultScreen();
    }
  }
}